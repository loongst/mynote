import configparser
import xlwings as xw
import os
import logging
import coloredlogs
import re


class myreplace:

    def __init__(self) -> None:

        #从配置文件获取信息
        config=configparser.ConfigParser()
        config.read('config.ini')

        #当前目录
        self.case_root_dir=os.getcwd()

        #配置日志打印
        coloredlogs.install(level='DEBUG', fmt='[%(levelname)s] %(asctime)s  %(message)s')
        logging.info('case_root_dir: '+self.case_root_dir)

        # 字典路径正则
        self.reg=re.compile(r'(D:\\工作\\测试效能平台\\字典\\)')
        #当前字典路径
        self.dict_path=(self.case_root_dir+"\\字典\\" ).replace("\\","\\\\")



    #获取excle并替换http路径
    def replace_http(self,filepath):
        wb=xw.Book(fullname=r'{}'.format(filepath))
        sheet=wb.sheets['Sheet1']
        
        rows_count=sheet.used_range.shape[0]
        logging.warning("row count: "+str(rows_count))
        for i in range(2,rows_count):
            course=sheet["E{}".format(i)]
            line=course.value
            line=line.replace('/websms',"hhahah")
            logging.error(line)
            course.value=line
        wb.close()


    #获取excle并替换字典路径
    def replace_dict(self,filepath):
        wb=xw.Book(fullname=r'{}'.format(filepath))
        sheet=wb.sheets['Sheet1']       
        rows_count=sheet.used_range.shape[0]
        logging.warning("row count: "+str(rows_count))
        for i in range(2,rows_count):
            try:
                courseG=sheet["G{}".format(i)].value
                courseH=sheet["H{}".format(i)].value
                if courseG and courseG.endswith(".txt"):
                    courseG=re.sub(self.reg,self.dict_path,courseG)
                if courseH and courseH.endswith(".txt"):
                    courseH=re.sub(self.reg,self.dict_path,courseH)
            except Exception as e:
                logging.error("handling line {} failed!".format(i))
                logging.error(e)
                            
        wb.close()



    #遍历目录下的文件
    def Traversal_file(self,filepath):
        for root,dirs,files in os.walk(filepath):
            abpath=os.path.join(root,file)
            logging.debug("handling... "+abpath)
            for file in files:
                if "http接口信息.xlsx"==file:
                    self.replace_http(abpath)
                elif "http接口用例" in file:
                    self.replace_dict(abpath)
                elif file.endwith("xlsx") :
                    logging.error("未识别的excle表")
                else:
                    pass





if __name__=='__main__':
    # repl=myreplace()
    # repl.Traversal_file()
    pass


# str1="status=ENUMFILE:D:\\工作\\测试效能平台\\字典\\xss注入.txt"

# print(str1)
# reg=re.compile(r'(D:\\工作\\测试效能平台\\字典\\)')

# path=os.getcwd()
# print(path)
# path=path.replace("\\","\\\\")
# print(path)
# path=path+("\\\\")
# print(path)
# ret=re.sub(reg, path ,str1)

# print("-----------")
# print(ret)
# print("-----------")

